When you will run the code(solution.c), it will display the Main Menu.
Then you have to enter the index of the query in the terminal to run it. 
It will run the asked query and then may ask you some input.
If the asked input is either yes or no, then enter "Yes" for yes and "No" for no.(this input is case sensitive!)
When a new menu pops up which has multiple queries the enter the index of the query to run it(same as we did in the main menu).
If the program asks you to enter the number of websites the enter the number of websites that you want to enter, then it will display the list of the websites with their indexes, you have to enter the index of websites and press Enter key after every input.
When you have entered the required number of indexes then the program will run the query.