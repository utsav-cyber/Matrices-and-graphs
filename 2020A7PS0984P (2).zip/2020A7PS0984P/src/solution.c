//MADE BY:-
//HEMESH GUPTA : 2020A7PS1688P
//PANKAJ PANJWANI : 2020A7PS0069P
//UTSAV GOEL : 2020A7PS0984P

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>

#define INF 1000000007

void printM1()
{
    printf("MAIN MENU\n1. Does every website has a link to itself? \n2. Is it possible to always return back to the previous website from the current website in one step? \n3. Does every website has all the links to the websites which are reachable from it? \n4. Does there exist any website that contains a link to itself? \n5. Is it impossible to return to the previous website from the current website in one step? \n6. Is it impossible to return to the previous website from the current website in one step(excluding the cases where the current and previous website is same)?\n7. Is it possible to divide the network into multiple pieces such that every website in a piece is reachable from every other website in that piece? \n8. Is this relation an example of poset? \n9. Exit\n");
}

void plot(char *fname)
{
//     int pid;
//     if ((pid = fork()) == 0)
//     {
//         if (execlp("python", "python", "visualise.py", fname, (char *)NULL) == -1)
//         {
//             execlp("python3", "python3", "visualise.py", fname, (char *)NULL);
//         };
//     }
//     exit(0);
}

void displayGraph(int n, int matrix[n][n], char websites[n][1024])
{
    FILE *fp;

    int i, j;

    fp = fopen("graph.csv", "w+");

    for (int i = 0; i < n; i++)
    {
        fprintf(fp, ",%s", websites[i]);
    }

    for (i = 0; i < n; i++)
    {

        fprintf(fp, "\n%s", websites[i]);

        for (j = 0; j < n; j++)
            fprintf(fp, ",%d", matrix[i][j]);
    }

    plot("graph.csv");

    fclose(fp);

    printf("graph plotted \n\n");
}

void openM2(int query, int n, int matrix[n][n], char websites[n][1024])
{
    printf("Do you want to visualise how the network will look if we add minimum links to satisfy the property?(Type Yes or No)\n");

    char reply[4];
    scanf("%s", reply);

    if (!strcmp(reply, "Yes"))
    {

        int temp[n][n];

        for (int i = 0; i < n; i++)
        {
            for (int j = 0; j < n; j++)
            {
                temp[i][j] = matrix[i][j];
            }
        }

        switch (query)
        {
        case 1:
            for (int i = 0; i < n; i++)
            {
                temp[i][i] = 1;
            }

            displayGraph(n, temp, websites);

            break;

        case 2:
            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j <= n; j++)
                {
                    if (temp[i][j] == 1)
                    {
                        temp[j][i] = 1;
                    }
                }
            }

            displayGraph(n, temp, websites);

            break;

        case 3:

            for (int k = 0; k < n; k++)
            {
                for (int i = 0; i < n; i++)
                {
                    for (int j = 0; j < n; j++)
                    {
                        temp[i][j] = temp[i][j] || (temp[i][k] && temp[k][j]);
                    }
                }
            }

            displayGraph(n, temp, websites);
            break;

        case 7:
            for (int i = 0; i < n; i++)
            {
                temp[i][i] = 1;
            }

            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < n; j++)
                {
                    if (i == j)
                    {
                        continue;
                    }

                    if (temp[i][j] == 1)
                    {
                        temp[j][i] = 1;
                    }
                }
            }

            ///code for transitive closure

            for (int k = 0; k < n; k++)
            {
                for (int i = 0; i < n; i++)
                {
                    for (int j = 0; j < n; j++)
                    {
                        temp[i][j] = temp[i][j] || (temp[i][k] && temp[k][j]);
                    }
                }
            }

            displayGraph(n, temp, websites);
            break;

        default:
            printf("Invalid query. Please enter a valid input\n");
            break;
        }
    }
    else
    {
        return;
    }
}

void openM3(int n, int matrix[n][n], char websites[n][1024])
{
    printf("Do you want to know the nodes in each piece?(Type Yes or No)\n");

    char reply[4];
    scanf("%s", reply);

    if (!strcmp(reply, "Yes"))
    {

        int temp[n][n];

        for (int i = 0; i < n; i++)
        {
            for (int j = 0; j < n; j++)
            {
                temp[i][j] = matrix[i][j];
            }
        }

        int flag[n];
        for (int i = 0; i < n; i++)
        {
            flag[i] = 1;
        }

        int partitionCount = 1;
        int elementCount = 0;
        for (int row = 0; row < n; row++)
        {
            if (elementCount == n)
            {
                break;
            }

            if (flag[row] == 0)
            {
                continue;
            }

            printf("P%d = {", partitionCount);

            for (int column = 0; column < n; column++)
            {

                if (temp[row][column] == 1)
                {
                    flag[column] = 0;
                    elementCount++;
                    printf("%s,", websites[column]);
                    for (int i = row; i < n; i++)
                    {
                        temp[i][column] = 0;
                    }
                }
            }
            partitionCount++;

            printf("}\n\n");
        }
    }
    else
    {
        return;
    }
}

void displayWebsiteWhichHasLinkOfEveryWebsite(int n, int matrix[n][n], char websites[n][1024])
{
    for (int row = 0; row < n; row++)
    {
        int sum = 0;
        for (int column = 0; column < n; column++)
        {
            if (matrix[row][column] == 1)
            {
                sum++;
            }
        }

        if (sum == n)
        {
            printf("%s\n", websites[row]);
        }
    }
}

void plotHasseDiagram(int n, int matrix[n][n], char websites[n][1024])
{
    int temp[n][n];

    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < n; j++)
        {
            temp[i][j] = matrix[i][j];
        }
    }

    for (int i = 0; i < n; i++)
    {
        temp[i][i] = 0;
    }

    for (int row = 0; row < n; row++)
    {
        for (int column = 0; column < n; column++)
        {
            if (temp[row][column] == 1)
            {
                for (int k = 0; k < n; k++)
                {
                    if (temp[column][k] == 1)
                    {
                        temp[row][k] = 0;
                    }
                }
            }
        }
    }

    displayGraph(n, temp, websites);
}

int isLattice(int n, int matrix[n][n], int lub[n][n], int glb[n][n])
{
    for (int e1 = 0; e1 < n - 1; e1++)
    {
        for (int e2 = e1 + 1; e2 < n; e2++)
        {

            // checking lub
            int count = 0;

            for (int column = 0; column < n; column++)
            {
                if (matrix[e1][column] == 1)
                {
                    if (matrix[e2][column] == 1)
                    {
                        count++;
                    }
                }
            }

            int arr[count];

            int temp = 0;

            for (int column = 0; column < n; column++)
            {
                if (matrix[e1][column] == 1 && matrix[e2][column] == 1)
                {
                    arr[temp] = column;
                    temp++;
                }
            }

            int globalFlag = 0;
            int lubcount = 0;

            for (int i = 0; i < count; i++)
            {
                int flag = 0;
                for (int j = 0; j < count; j++)
                {
                    if (i == j)
                    {
                        continue;
                    }

                    if (matrix[arr[j]][arr[i]] == 1)
                    {

                        flag = 1;
                        break;
                    }
                }

                if (flag == 0)
                {
                    globalFlag = 1;
                    lub[e1][e2] = arr[i];
                    lub[e2][e1] = arr[i];
                    lubcount++;
                }
            }

            if (lubcount > 1)
            {
                return 0;
            }

            if (globalFlag == 0)
            {
                return 0;
            }

            // checking glb

            int count2 = 0;

            for (int column = 0; column < n; column++)
            {
                if (matrix[column][e1] == 1)
                {
                    if (matrix[column][e2] == 1)
                    {
                        count2++;
                    }
                }
            }

            int arr2[count2];

            int temp2 = 0;

            for (int column = 0; column < n; column++)
            {
                if (matrix[column][e1] == 1 && matrix[column][e2] == 1)
                {
                    arr2[temp2] = column;
                    temp2++;
                }
            }

            int globalFlag2 = 0, glbcount = 0;

            for (int i = 0; i < count2; i++)
            {
                int flag = 0;
                for (int j = 0; j < count2; j++)
                {
                    if (i == j)
                    {
                        continue;
                    }

                    if (matrix[arr2[i]][arr2[j]] == 1)
                    {

                        flag = 1;
                        break;
                    }
                }

                if (flag == 0)
                {
                    globalFlag2 = 1;
                    glb[e1][e2] = arr2[i];
                    glb[e2][e1] = arr2[i];
                    glbcount++;
                }
            }

            if (glbcount > 1)
            {
                return 0;
            }

            if (globalFlag2 == 0)
            {
                return 0;
            }
        }
    }

    return 1;
}

void findLUB(int n, int lub[n][n], char websites[n][1024])
{
    printf("Please enter the index numbers of the two websites:\n");
    for (int i = 0; i < n; i++)
    {
        printf("%d. %s\n", i + 1, websites[i]);
    }

    int a, b;
    scanf("%d %d", &a, &b);

    printf("The website which is reachable by both the websites and can reach to all the websites that A and B can reach is : \n%s\n", websites[lub[a - 1][b - 1]]);
}

void findGLb(int n, int glb[n][n], char websites[n][1024])
{
    printf("Please enter the index numbers of the two websites:\n");
    for (int i = 0; i < n; i++)
    {
        printf("%d. %s\n", i + 1, websites[i]);
    }

    int a, b;
    scanf("%d %d", &a, &b);

    printf("The website which can both the websites and is also reachable from all the websites which can reach to A and B is : \n%s\n", websites[glb[a - 1][b - 1]]);
}

int isDistributive(int n, int matrix[n][n], int lub[n][n], int glb[n][n])
{
    for (int a = 0; a < n; a++)
    {
        for (int b = 0; b < n; b++)
        {
            for (int c = 0; c < n; c++)
            {
                int t1 = lub[a][glb[b][c]];
                int t2 = glb[lub[a][b]][lub[a][c]];

                if (t1 != t2)
                {
                    return 0;
                }

                int t3 = glb[a][lub[b][c]];
                int t4 = lub[glb[a][b]][glb[a][c]];
                if (t3 != t4)
                {
                    return 0;
                }
            }
        }
    }

    return 1;
}

void openM5(int n, int matrix[n][n], char websites[n][1024], int lub[n][n], int glb[n][n])
{

    while (1)
    {

        printf("1. Given two websites A and B, display the website which is reachable by both A and B and can also reach to all such websites that both A and B can reach.\n2. Given two websites A and B, display the website which can reach to both A and B and is also reachable from all such websites which can reach to both A and B.\n3. Is the lattice distributive?\n4. Return to Menu 4\n");

        int menu4Query;
        scanf("%d", &menu4Query);

        switch (menu4Query)
        {
        case 1:
            findLUB(n, lub, websites);
            break;

        case 2:
            findGLb(n, glb, websites);
            break;

        case 3:
            if (isDistributive(n, matrix, lub, glb))
            {
                printf("Yes\n");
            }
            else
            {
                printf("No\n");
            }
            break;

        case 4:
            return;
            break;

        default:
            printf("Invalid query. Please enter a valid input\n");
            break;
        }
    }
}

//Menu 4 functions
void websiteWhoseLinkIsAvailableInEveryWebsite(int n, int matrix[n][n], char websites[n][1024])
{
    int flag = 0;

    for (int column = 0; column < n; column++)
    {
        int sum = 0;
        for (int row = 0; row < n; row++)
        {
            if (matrix[row][column] == 1)
            {
                sum++;
            }
        }

        if (sum == n)
        {
            printf("%s\n", websites[column]);
            flag = 1;
        }
    }

    if (flag == 0)
    {
        printf("No such websites exists\n");
    }
}

void websiteWhichHasLinkOfEveryWebsite(int n, int matrix[n][n], char websites[n][1024])
{
    int flag = 0;

    for (int row = 0; row < n; row++)
    {
        int sum = 0;
        for (int column = 0; column < n; column++)
        {
            if (matrix[row][column] == 1)
            {
                sum++;
            }
        }

        if (sum == n)
        {
            printf("%s\n", websites[row]);
            flag = 1;
        }
    }

    if (flag == 0)
    {
        printf("No such websites exists\n");
    }
}

void displayWebsiteWhichHasLinkToItself(int n, int matrix[n][n], char websites[n][1024])
{
    int gflag = 0;

    for (int i = 0; i < n; i++)
    {
        int flag = 1;

        if (matrix[i][i] == 1)
        {
            for (int j = 0; j < n; j++)
            {
                if (i == j)
                {
                    continue;
                }

                if (matrix[i][j] == 1)
                {
                    flag = 0;
                    break;
                }
            }
        }

        if (flag == 1)
        {
            printf("%s\n", websites[i]);
            gflag = 1;
        }
    }

    if (gflag == 0)
    {
        printf("No such websites exists\n");
    }
}

void displayWebsiteWhichAreReachableFromItselfOnly(int n, int matrix[n][n], char websites[n][1024])
{
    int gflag = 0;

    for (int i = 0; i < n; i++)
    {
        int flag = 1;
        if (matrix[i][i] == 1)
        {
            for (int j = 0; j < n; j++)
            {
                if (i == j)
                {
                    continue;
                }

                if (matrix[j][i] == 1)
                {
                    flag = 0;
                    break;
                }
            }
        }

        if (flag == 1)
        {
            printf("%s\n", websites[i]);
            gflag = 1;
        }
    }

    if (gflag == 0)
    {
        printf("No such websites exists\n");
    }
}

void displayWebsitesWhichAreReachableFromGivenWebsites(int n, int matrix[n][n], char websites[n][1024])
{
    printf("Please enter the number of websites you want to enter.\n");
    int noOfInput;

    scanf("%d", &noOfInput);

    int input[n];

    for (int i = 0; i < n; i++)
    {
        input[i] = 0;
    }

    printf("Please enter the index number of websites:\n");
    for (int i = 0; i < n; i++)
    {
        printf("%d. %s\n", i + 1, websites[i]);
    }

    for (int i = 0; i < noOfInput; i++)
    {
        int temp;
        scanf("%d", &temp);

        input[temp - 1] = 1;
    }

    printf("The given websites are reachable from all of them.\n");

    for (int column = 0; column < n; column++)
    {
        int sum = 0;

        for (int row = 0; row < n; row++)
        {
            if (input[row] == 0)
            {
                continue;
            }

            if (matrix[row][column] == 1)
            {
                sum++;
            }
        }

        if (sum == noOfInput)
        {
            printf("%s\n", websites[column]);
        }
    }
}

void displayWebsitesFromWhichWeCanReachAllTheGivenWebsites(int n, int matrix[n][n], char websites[n][1024])
{
    printf("Please enter the number of websites you want to enter.\n");

    int noOfInput;

    scanf("%d", &noOfInput);

    int input[n];

    for (int i = 0; i < n; i++)
    {
        input[i] = 0;
    }

    printf("Please enter the index number of websites:\n");
    for (int i = 0; i < n; i++)
    {
        printf("%d. %s\n", i + 1, websites[i]);
    }

    for (int i = 0; i < noOfInput; i++)
    {
        int temp;
        scanf("%d", &temp);

        input[temp - 1] = 1;
    }

    printf("From the given websites we can reach to all of them.\n");

    for (int row = 0; row < n; row++)
    {
        int sum = 0;

        for (int column = 0; column < n; column++)
        {
            if (input[column] == 0)
            {
                continue;
            }

            if (matrix[row][column] == 1)
            {
                sum++;
            }
        }

        if (sum == noOfInput)
        {
            printf("%s\n", websites[row]);
        }
    }
}

void openM4(int n, int matrix[n][n], char websites[n][1024])
{

    int temp[n][n];

    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < n; j++)
        {
            temp[i][j] = matrix[i][j];
        }
    }

    int lub[n][n];
    int glb[n][n];

    while (1)
    {
        printf("MENU 4\n1. Display the hasse diagram.\n2. Display the website whose link is available in every website.\n3. Display the website which has links of every website.\n4. Display the websites that do not have links to any other website except itself.\n5. Display the websites which can't be reached from any other website except itself.\n6. Given some websites, display the websites which are reachable from all of them.\n7. Given some websites, display the websites from which you can reach all those websites.\n8. Is this relation an example of lattice?\n9. Return to Main Menu.\n");
        int menu4Query;
        scanf("%d", &menu4Query);

        switch (menu4Query)
        {
        case 1:
            plotHasseDiagram(n, matrix, websites);
            break;

        case 2:
            // displays the name of website whose link is available in every website

            websiteWhoseLinkIsAvailableInEveryWebsite(n, matrix, websites);
            break;

        case 3:
            // displays the name of website which has the link of every website

            websiteWhichHasLinkOfEveryWebsite(n, matrix, websites);
            break;

        case 4:

            //displays websites which has link to itself only

            displayWebsiteWhichHasLinkToItself(n, matrix, websites);
            break;

        case 5:

            //displays websites which are reachable from itself only

            displayWebsiteWhichAreReachableFromItselfOnly(n, matrix, websites);
            break;

        case 6:

            displayWebsitesWhichAreReachableFromGivenWebsites(n, matrix, websites);
            break;

        case 7:

            displayWebsitesFromWhichWeCanReachAllTheGivenWebsites(n, matrix, websites);
            break;

        case 8:

            if (isLattice(n, matrix, lub, glb))
            {
                printf("Yes\n");
                openM5(n, matrix, websites, lub, glb);
            }
            else
            {
                printf("No\n");
            }

            break;

        case 9:
            return;
            break;

        default:
            printf("Invalid query. Please enter a valid input\n");
            break;
        }
    }
}

// functions for menu 1
int isReflexive(int n, int matrix[n][n])
{
    for (int i = 0; i < n; i++)
    {
        if (matrix[i][i] == 0)
        {
            return 0;
        }
    }
    return 1;
}

int isSymmetric(int n, int matrix[n][n])
{
    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < n; j++)
        {
            if (matrix[i][j] == 1)
            {
                if (matrix[j][i] == 1)
                {
                    continue;
                }
                else
                {
                    return 0;
                }
            }
        }
    }
    return 1;
}

int isTransitive(int n, int matrix[n][n])
{
    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < n; j++)
        {
            for (int k = 0; k < n; k++)
            {
                if (matrix[i][j] == 1 && matrix[j][k] == 1)
                {
                    if (matrix[i][k] != 1)
                    {
                        return 0;
                    }
                }
            }
        }
    }

    return 1;
}

int anyoneHasLinkToItself(int n, int matrix[n][n])
{
    for (int i = 0; i < n; i++)
    {
        if (matrix[i][i] == 1)
        {
            return 1;
        }
    }

    return 0;
}

int isImpossibleToReturn(int n, int matrix[n][n])
{
    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j <= n; j++)
        {
            if (matrix[i][j] == 1)
            {
                if (matrix[j][i] == 0)
                {
                    continue;
                }
                else
                {
                    return 0;
                }
            }
        }
    }
    return 1;
}

int isImpossibleToReturnExcludingSameWebsite(int n, int matrix[n][n])
{
    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j <= n; j++)
        {
            if (i == j)
            {
                continue;
            }

            if (matrix[i][j] == 1)
            {
                if (matrix[j][i] == 0)
                {
                    continue;
                }
                else
                {
                    return 0;
                }
            }
        }
    }
    return 1;
}

int isEquivalence(int n, int matrix[n][n])
{

    for (int i = 0; i < n; i++)
    {
        if (matrix[i][i] == 0)
        {
            return 0;
        }
    }

    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < n; j++)
        {
            if (matrix[i][j] == 1)
            {
                if (matrix[j][i] == 1)
                {
                    continue;
                }
                else
                {
                    return 0;
                }
            }
        }
    }

    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < n; j++)
        {
            for (int k = 0; k < n; k++)
            {
                if (matrix[i][j] == 1 && matrix[j][k] == 1)
                {
                    if (matrix[i][k] != 1)
                    {
                        return 0;
                    }
                }
            }
        }
    }

    return 1;
}

int isPoset(int n, int matrix[n][n])
{
    for (int i = 0; i < n; i++)
    {
        if (matrix[i][i] == 0)
        {
            return 0;
        }
    }

    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < n; j++)
        {
            if (i == j)
            {
                continue;
            }

            if (matrix[i][j] == 1)
            {
                if (matrix[j][i] == 1)
                {
                    return 0;
                }
            }
        }
    }

    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < n; j++)
        {
            for (int k = 0; k < n; k++)
            {
                if (matrix[i][j] == 1 && matrix[j][k] == 1)
                {
                    if (matrix[i][k] != 1)
                    {
                        return 0;
                    }
                }
            }
        }
    }

    return 1;
}

int main()
{
    ////Taking input
    FILE *file = fopen("SampleInput.csv", "r");

    if (file == NULL)
    {
        perror("Unable to open the file");
        exit(1);
    }

    char line[1024];

    fgets(line, sizeof(line), file);

    char *token = strtok(line, ",");

    int n = 0;

    while (token != NULL)
    {
        n++;
        token = strtok(NULL, ",");
    }

    char websites[n][1024];
    int matrix[n][n];

    for (int i = 0; i < n; i++)
    {
        int k = 0;
        char c;

        while (1)
        {
            c = fgetc(file);
            websites[i][k] = c;

            if (c == ',')
                break;
            k++;
        }

        websites[i][k] = '\0';

        for (k = 0; k < n - 1; k++)
        {
            fscanf(file, "%d,", &matrix[i][k]);
        }
        fscanf(file, "%d\n", &matrix[i][k]);
    }

    ////

    while (1)
    {
        printM1();

        int mainMenuQuery;
        scanf("%d", &mainMenuQuery);

        switch (mainMenuQuery)
        {
        case 1:
            if (isReflexive(n, matrix))
            {
                printf("Yes\n\n");
            }
            else
            {
                printf("No\n\n");
                openM2(1, n, matrix, websites);
            }
            break;

        case 2:
            if (isSymmetric(n, matrix))
            {
                printf("Yes\n\n");
            }
            else
            {
                printf("No\n\n");
                openM2(2, n, matrix, websites);
            }
            break;

        case 3:
            if (isTransitive(n, matrix))
            {
                printf("Yes\n\n");
            }
            else
            {
                printf("No\n\n");
                openM2(3, n, matrix, websites);
            }
            break;

        case 4:
            if (anyoneHasLinkToItself(n, matrix))
            {
                printf("Yes\n\n");
            }
            else
            {
                printf("No\n\n");
            }
            break;

        case 5:
            if (isImpossibleToReturn(n, matrix))
            {
                printf("Yes\n\n");
            }
            else
            {
                printf("No\n\n");
            }
            break;

        case 6:
            if (isImpossibleToReturnExcludingSameWebsite(n, matrix))
            {
                printf("Yes\n\n");
            }
            else
            {
                printf("No\n\n");
            }
            break;

        case 7:
            if (isEquivalence(n, matrix))
            {
                printf("Yes\n\n");
                openM3(n, matrix, websites);
            }
            else
            {
                printf("No\n\n");
                openM2(7, n, matrix, websites);
            }
            break;

        case 8:
            if (isPoset(n, matrix))
            {
                printf("Yes\n\n");
                openM4(n, matrix, websites);
            }
            else
            {
                printf("No\n\n");
            }
            break;

        case 9:
            printf("Exiting the program\nThank You!\n");
            exit(0);
            break;

        default:
            printf("Invalid query. Please enter a valid input\n");
            break;
        }
    }
    return 0;
}
